Web based interface for controlling the Raspberry Pi Camera, includes motion detection, time lapse, and image and video recording.

All information on this project can be found here: http://www.raspberrypi.org/forums/viewtopic.php?f=43&t=63276

The wiki page can be found here:

http://elinux.org/RPi-Cam-Web-Interface
