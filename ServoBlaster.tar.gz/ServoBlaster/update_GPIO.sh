#!/bin/sh

wget https://seacloud.cc/f/3dcdfe6071/?dl=1 -O /home/pi/ServoBlaster/GPIO_WIP.py
